#pragma once

#include <exception>

class InterperterException : public std::exception
{
public:

private:

};

