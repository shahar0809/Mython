#include "parser.h"

Type* Parser::parseString(std::string str) throw()
{
	Helper::removeLeadingZeros(str);
	/*Checking if the command starts with a space or a tab.*/
	if (str[0] == ' ' || str[0] == '\t')
	{
		throw(IndentationException());
	}
	
	Type* t = Parser::getType(str);
	if (t != NULL)
	{
		return t;
	}
}

Type* Parser::getType(std::string& str)
{
	Type* type;
	if (Helper::isBoolean(str))
	{
		if (str[0] == 'T')
		{
			type = new Boolean(true);
		}
		else
		{
			type = new Boolean(false);
		}
	}
	else if (Helper::isInteger(str))
	{
		type = new Integer(std::stoi(str));
	}
	else if (Helper::isString(str))
	{
		str[0] = char(39), str[str.size() - 1] = char(39);
		type = new String(str);
	}
	else
	{
		type = nullptr;
		throw(SyntaxException());
	}
	type->setIsTemp(true);
	return type;
}

bool Parser::isLegalVarName(const std::string& str)
{
	if (Helper::isDigit(str[0]))
		return false;

	for (int i = 0; i < str.size(); i++)
	{
		if (!Helper::isLetter(str[0]) && !Helper::isDigit(str[0]) && Helper::isUnderscore(str[0]))
		{
			return false;
		}
	}
	return true;
}

bool Parser::ParsermakeAssignment(const std::string& str)
{
	if (str.find("=") != 1)
		return false;

	std::string varName = str.substr(0, str.find_first_of("="));
	std::string op = str.substr(str.find_first_of("=") + 1);
	
	return Parser::isLegalVariableName(varName) && 
}
